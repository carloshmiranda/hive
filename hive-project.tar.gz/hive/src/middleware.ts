export { auth as middleware } from "@/lib/auth";

export const config = {
  matcher: [
    // Protect everything except: login, auth API, webhooks, cron, health, briefing, context, static files
    "/((?!login|api/auth|api/webhooks|api/cron|api/health|api/briefing|api/context|_next/static|_next/image|favicon.ico).*)",
  ],
};
